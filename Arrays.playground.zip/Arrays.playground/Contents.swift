import UIKit

var greeting = "Basic Program on Playground"

// Array
var someInts:[Int]=[10,20,30,40]
var someVar = someInts[0]
print( "Value of first element is \(someVar)" )
print( "Value of second element is \(someInts[1])" )
print( "Value of third element is \(someInts[2])" )



//String
// Empty string creation using String literal
var stringA = "Hello, Guys"
if stringA.isEmpty {
print( "stringA is empty" )
} else {
print( "stringA is not empty" )
}





// Empty string creation using String instance
let stringB = String()
if stringB.isEmpty {
print( "stringB is empty" )
} else {
print( "stringB is not empty" )
}




//String Concatination
let constA = "Hello,"
let constB = "World!"
var stringC = constA + constB
print( stringC )





//String Length
print( "\(greeting), length is \((greeting.count))" )
//String Comparision
;


var varA = "Hello, Swift!"
var varB = "Hello, World!"
if varA == varB {
print( "\(varA) and \(varB) are equal" )
} else {
print( "\(varA) and \(varB) are not equal" )
}



//Function
//Function with parameters
func mult(no1: Int, no2: Int) -> Int {
return no1*no2
}
print(mult(no1: 2, no2: 20))
print(mult(no1: 3, no2: 15))
print(mult(no1: 4, no2: 30))

//Function without Parameters
func votersname()->String{
    return"Yugesh"
}
print(votersname())



